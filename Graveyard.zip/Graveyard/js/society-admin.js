document.addEventListener('DOMContentLoaded', () => {
    // Initialize sections
    const sections = document.querySelectorAll('.section');
    const menuItems = document.querySelectorAll('.menu-item');
    const submenuItems = document.querySelectorAll('.submenu-item');
    const addResidentForm = document.getElementById('addResidentForm');
    const modal = document.getElementById('modal');
    const closeButton = document.querySelector('.close-button');
  
    // Function to hide all sections
    const hideAllSections = () => {
      sections.forEach(section => {
        section.classList.add('hidden');
        section.classList.remove('active');
      });
    };
  
    // Function to deactivate all menu items
    const deactivateMenuItems = () => {
      menuItems.forEach(item => item.classList.remove('active'));
      submenuItems.forEach(item => item.classList.remove('active'));
    };
  
    // Function to show a specific section
    const showSection = (sectionId) => {
      hideAllSections();
      deactivateMenuItems();
  
      const targetSection = document.getElementById(sectionId);
      if (targetSection) {
        targetSection.classList.remove('hidden');
        targetSection.classList.add('active');
      }
  
      // Activate the corresponding menu item
      if (sectionId === 'graveyardStats' || sectionId === 'graves') {
        const menuItem = document.querySelector(`.menu-item[data-section="${sectionId}"]`);
        if (menuItem) menuItem.classList.add('active');
      } else if (sectionId === 'allResidents' || sectionId === 'addResident') {
        const parentMenu = document.querySelector(`.menu-item[data-section="residents"]`);
        if (parentMenu) parentMenu.classList.add('active');
  
        const submenuItem = document.querySelector(`.submenu-item[data-section="${sectionId}"]`);
        if (submenuItem) submenuItem.classList.add('active');
      }
    };
  
    // Event listeners for main menu items
    menuItems.forEach(item => {
      item.addEventListener('click', () => {
        const sectionId = item.getAttribute('data-section');
        showSection(sectionId);
      });
    });
  
    // Event listeners for submenu items
    submenuItems.forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation(); // Prevent triggering parent menu click
        const sectionId = item.getAttribute('data-section');
        showSection(sectionId);
      });
    });
  
    // Handle Add Resident Form Submission
    addResidentForm.addEventListener('submit', (e) => {
      e.preventDefault();
  
      const name = document.getElementById('residentName').value.trim();
      const id = document.getElementById('residentID').value.trim();
      const plot = document.getElementById('residentPlot').value.trim();
  
      if (name && id && plot) {
        // Create a new profile card
        const profilesContainer = document.getElementById('allResidents').querySelector('.profiles');
        const newProfile = document.createElement('div');
        newProfile.className = 'profile-card';
        newProfile.innerHTML = `
          <img src="./images/default.jpg" alt="${name}">
          <h3>${name}</h3>
          <p>Resident ID: ${id}</p>
          <p>Plot: ${plot}</p>
          <button>View Details</button>
        `;
        profilesContainer.appendChild(newProfile);
  
        // Reset the form
        addResidentForm.reset();
  
        // Show success modal
        modal.classList.remove('hidden');
      }
    });
  
    // Close modal
    closeButton.addEventListener('click', () => {
      modal.classList.add('hidden');
    });
  
    // Close modal when clicking outside the modal content
    window.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.add('hidden');
      }
    });
  
    // Initialize default view
    showSection('graveyardStats');
  });
  
      // Graveyard Details
  document.addEventListener('DOMContentLoaded', () => {
    const graveGrid = document.querySelector('.grave-grid');
    const totalPlots = 200; // Total number of plots
    const bookedPlots = 20; // Number of booked plots

    // Generate graveyard plots dynamically
    for (let i = 1; i <= totalPlots; i++) {
      const graveCard = document.createElement('div');
      graveCard.className = `grave-card ${i <= bookedPlots ? 'booked' : 'available'}`;
      graveCard.textContent = `Plot ${i}`;

      // Add click event for available plots
      if (i > bookedPlots) {
        graveCard.addEventListener('click', () => {
          // Toggle selection
          if (graveCard.classList.contains('selected')) {
            graveCard.classList.remove('selected');
          } else {
            graveCard.classList.add('selected');
          }
        });
      }

      graveGrid.appendChild(graveCard);
    }
  });