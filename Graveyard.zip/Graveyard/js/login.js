document.addEventListener('DOMContentLoaded', () => {
    const signInBtn = document.getElementById('signInBtn');
    const signUpBtn = document.getElementById('signUpBtn');
    const signInForm = document.getElementById('signInForm');
    const signUpForm = document.getElementById('signUpForm');
    const switchToSignUp = document.querySelector('.switch-to-signup');
    const switchToSignIn = document.querySelector('.switch-to-signin');

    // Switch to Sign Up Form
    signUpBtn.addEventListener('click', () => {
        signInForm.classList.add('hidden');
        signUpForm.classList.remove('hidden');
        signInBtn.classList.remove('active');
        signUpBtn.classList.add('active');
    });

    // Switch to Sign In Form
    signInBtn.addEventListener('click', () => {
        signUpForm.classList.add('hidden');
        signInForm.classList.remove('hidden');
        signUpBtn.classList.remove('active');
        signInBtn.classList.add('active');
    });

    // Switch from Sign In to Sign Up on text click
    switchToSignUp.addEventListener('click', () => {
        signUpForm.classList.remove('hidden');
        signInForm.classList.add('hidden');
        signInBtn.classList.remove('active');
        signUpBtn.classList.add('active');
    });

    // Switch from Sign Up to Sign In on text click
    switchToSignIn.addEventListener('click', () => {
        signInForm.classList.remove('hidden');
        signUpForm.classList.add('hidden');
        signUpBtn.classList.remove('active');
        signInBtn.classList.add('active');
    });

    // Sign In Form Submission (Add validation or AJAX here)
    signInForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // Add login logic here, such as validation or AJAX request
        alert('Logged in successfully!');
    });

    // Sign Up Form Submission (Add validation or AJAX here)
    signUpForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // Add signup logic here, such as validation or AJAX request
        alert('Signed up successfully!');
    });
});
