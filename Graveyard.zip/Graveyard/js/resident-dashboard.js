document.addEventListener('DOMContentLoaded', () => {
  // Sidebar interactions
  const menuItems = document.querySelectorAll('.menu-item');
  const sections = document.querySelectorAll('.section');
  
  menuItems.forEach(item => {
    item.addEventListener('click', () => {
      // Hide all sections and remove active class from all menu items
      sections.forEach(section => section.classList.remove('active'));
      menuItems.forEach(i => i.classList.remove('active'));

      // Show the clicked section and add active class to menu item
      const sectionId = item.getAttribute('data-section');
      document.getElementById(sectionId).classList.add('active');
      item.classList.add('active');
    });
  });

  // Book New Grave form handling
  const bookGraveForm = document.getElementById('bookGraveForm');
  const confirmationMessage = document.getElementById('confirmationMessage');

  // Initially hide the confirmation message
  confirmationMessage.classList.add('hidden');

  bookGraveForm.addEventListener('submit', (e) => {
    e.preventDefault();

    // Simulate booking process
    confirmationMessage.classList.remove('hidden'); // Show confirmation message
    
    // Reset form after submission
    bookGraveForm.reset();
  });

  // Graveyard Map interaction
  const graveGrid = document.querySelector('.grave-grid');
  const totalPlots = 200;  // Total number of plots in the graveyard
  const bookedPlots = [1, 2, 3, 10, 11, 12];  // Example list of booked plot numbers (adjust this array as needed)

  // Generate graveyard plots dynamically
  for (let i = 1; i <= totalPlots; i++) {
    const graveCard = document.createElement('div');
    graveCard.classList.add('grave-card');
    graveCard.textContent = `Plot ${i}`;

    // Add class based on availability
    if (bookedPlots.includes(i)) {
      graveCard.classList.add('booked');  // If plot is booked, apply the 'booked' class
    } else {
      graveCard.classList.add('available');  // If plot is available, apply the 'available' class
      graveCard.addEventListener('click', () => {
        // Handle plot selection for available plots
        if (graveCard.classList.contains('available')) {
          graveCard.classList.toggle('selected');
        }
      });
    }

    graveGrid.appendChild(graveCard);
  }
});
